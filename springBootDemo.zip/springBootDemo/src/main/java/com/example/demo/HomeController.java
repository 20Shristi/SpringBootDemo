package com.example.demo;

//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


//@Controller
@RestController
public class HomeController {
	
	@RequestMapping("/test")
//  @ResponsBody	
	public String handlerHome() {
		
		return "This is first project in Spring Boot";
	}
	

}
